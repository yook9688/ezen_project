package application.model;

import java.time.LocalDate;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class Notice {

	
	private final StringProperty noticeNum;
	private final StringProperty noticeTitle;
	private final StringProperty noticeContent;
	private final ObjectProperty<LocalDate> writeDate;
	private final StringProperty lookUp;
	
	
	/*
	 * ����Ʈ ������
	 * */
	
	public Notice() {
		this(null,null,null,null,null);
	}

	/*
	 * �����͸� �ʱ�ȭ �ϴ� ������
	 * */
	
	public Notice(String noticeNum, String noticeTitle, String noticeContent, LocalDate writeDate, String lookUp) {
		this.noticeNum = new SimpleStringProperty(noticeNum);
		this.noticeTitle = new SimpleStringProperty(noticeTitle);
		this.noticeContent = new SimpleStringProperty(noticeContent);
		this.writeDate = new SimpleObjectProperty<LocalDate>(writeDate);
		this.lookUp = new SimpleStringProperty(lookUp);
		
		
	}

	public String getNoticeNum() { return noticeNum.get(); }
	public void setNoticeNum(String noticeNum ) { this.noticeNum.set(noticeNum);}
	public StringProperty noticeNumProperty() {return noticeNum;}

	public String getNoticeTitle() {return noticeTitle.get();}
	public void setNoticeTitle(String noticeTitle) {this.noticeTitle.set(noticeTitle);}
	public StringProperty noticeTitleProperty() {return noticeTitle;}

	public String getNoticeContent() {return noticeContent.get();}
	public void setNoticeContent(String noticeContent) {this.noticeContent.set(noticeContent);}
	public StringProperty NoticeContentProperty() {	return noticeContent;}

	public LocalDate getWriteDate() { return writeDate.get();}
	public void setWriteDate(LocalDate writeDate) { this.writeDate.set(writeDate); }
	public ObjectProperty<LocalDate> writeDateProperty() {return writeDate;}

	public String getLookUp() {	return lookUp.get();}
	public void setLookUp(String lookUp) {this.lookUp.set(lookUp);}
	public StringProperty lookUpProperty() {return lookUp;}
	
	
}
