package application.model;

import java.time.LocalDate;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Review {
	private final StringProperty num3;
	private final StringProperty tit3;
	private final StringProperty id3;
	private final ObjectProperty<LocalDate> date3;
	private final StringProperty view3;
	
	
	public Review() {
		this(null, null, null, null, null);
	}
	public Review(String num3, String tit3, String id3, LocalDate date3, String view3) {
		this.num3 = new SimpleStringProperty(num3);
		this.tit3 = new SimpleStringProperty(tit3);
		this.id3 = new SimpleStringProperty(id3);
		this.date3 = new SimpleObjectProperty<LocalDate>(date3);
		this.view3 = new SimpleStringProperty(view3);
		
	}
	
	
	public String getNum() { return num3.get(); }
	public void setNum(String num3) { this.num3.set(num3); }
	public StringProperty num3Property() { return num3; }
	
	public String getTit() {return tit3.get(); }
	public void setTit(String tit3) { this.tit3.set(tit3);}
	public StringProperty tit3Property() {return tit3;}
	
	public String getId() { return id3.get(); }
	public void setId(String id3) { this.id3.set(id3); }
	public StringProperty id3Property() { return id3; }
	
	public LocalDate getDate() { return date3.get();}
	public void setDate(LocalDate date3) { this.date3.set(date3); }
	public ObjectProperty<LocalDate> date3Property() {return date3;}
	
	public String getView() {return view3.get();}
	public void setView(String view3) { this.view3.set(view3); }
	public StringProperty view3Property() {return view3;}

	}

	


