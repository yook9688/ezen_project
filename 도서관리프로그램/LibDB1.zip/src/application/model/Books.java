package application.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/*
 * ����ó �� Ŭ����
 * 
 * @author Marco Jakob
 * */

public class Books {

	private final StringProperty category;
	private final StringProperty bookTitle;
	private final StringProperty authur;
	private final StringProperty company;
	private final StringProperty price;
	private final StringProperty each;
	
	
	/*
	 * ����Ʈ ������
	 * */
	
	public Books() {
		this(null,null,null,null, null, null);
	}

	/*
	 * �����͸� �ʱ�ȭ �ϴ� ������
	 * 
	 * @param category
	 * @param bookTitle
	 * */
	
	public Books(String category, String bookTitle, String authur, String company, String price, String each ) {
		this.category = new SimpleStringProperty(category);
		this.bookTitle = new SimpleStringProperty(bookTitle);
		this.authur = new SimpleStringProperty(authur);
		this.company = new SimpleStringProperty(company);
		this.price = new SimpleStringProperty(price);
		this.each = new SimpleStringProperty(each);
		
		
	}

	public String getCategory() {
		return category.get();
	}
	public void setCategory(String category ) {
		this.category.set(category);
	}
	public StringProperty categoryProperty() {
		return category;
	}
/////////////////////////////////////////////////////////
	public String getbookTitle() {
		return bookTitle.get();
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle.set(bookTitle);
	}
	public StringProperty bookTitleProperty() {
		return bookTitle;
	}
////////////////////////////////////////////////////////
	public String getAuthur() {
		return authur.get();
	}
	public void setAthur(String authur) {
		this.authur.set(authur);
	}
	public StringProperty authurProperty() {
		return authur;
	}
///////////////////////////////////////////////////////
	public String getCompany() {
		return company.get();
	}
	public void setCompany(String company) {
		this.company.set(company);
	}
	public StringProperty companyProperty() {
		return company;
	}
///////////////////////////////////////////////////////
	public String getPrice() {
		return price.get();
	}
	public void setPrice(String price) {
		this.price.set(price);
	}
	public StringProperty priceProperty() {
		return price;
	}
////////////////////////////////////////////////////////
	public String getEach() {
		return each.get();
	}
	public void setEach(String each) {
		this.each.set(each);
	}
	public StringProperty eachProperty(){
		return each;
	}
	
	
	
}
