package application.model;

import java.time.LocalDate;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Sell_list {
	private final StringProperty cate;
	private final StringProperty tit;
	private final StringProperty auth;
	private final StringProperty com;
	private final StringProperty pri;
	private final StringProperty id;
	private final StringProperty paid;
	private final ObjectProperty<LocalDate> date;
	private final StringProperty sor;
	
	
	public Sell_list() {
		this(null, null, null, null, null, null, null, null, null);
	}
	public Sell_list(String cate, String tit, String auth, String com, String pri, String id, String paid, LocalDate date, String sor) {
		this.cate = new SimpleStringProperty(cate);
		this.tit = new SimpleStringProperty(tit);
		this.auth = new SimpleStringProperty(auth);
		this.com = new SimpleStringProperty(com);
		this.pri = new SimpleStringProperty(pri);
		this.id = new SimpleStringProperty(id);
		this.paid = new SimpleStringProperty(paid);
		this.date = new SimpleObjectProperty<LocalDate>(date);
		this.sor = new SimpleStringProperty(sor);
		
	}
	
	
	public String getCate() { return cate.get(); }
	public void setCate(String cate) { this.cate.set(cate); }
	public StringProperty cateProperty() { return cate; }
	
	public String getTit() {return tit.get(); }
	public void setTit(String tit) { this.tit.set(tit);}
	public StringProperty titProperty() {return tit;}
	
	public String getAuth() { return auth.get(); }
	public void setAuth(String auth) { this.auth.set(auth); }
	public StringProperty authProperty() { return auth; }
	
	public String getCom() { return com.get(); }
	public void setCom(String com) { this.com.set(com); }
	public StringProperty comProperty() { return com; }
	
	public String getPri() {return pri.get();}
	public void setPri(String pri) { this.pri.set(pri); }
	public StringProperty priProperty() {return pri;}
	
	public String getId() {return id.get();}
	public void setId(String id) { this.id.set(id); }
	public StringProperty idProperty() {return id;}
	
	public String getPaid() {return paid.get();}
	public void setPaid(String paid) { this.paid.set(paid); }
	public StringProperty paidProperty() {return paid;}
	
	public LocalDate getDate() { return date.get();}
	public void setDate(LocalDate date) { this.date.set(date); }
	public ObjectProperty<LocalDate> dateProperty() {return date;}
	
	public String getSor() {return sor.get();}
	public void setSor(String sor) { this.sor.set(sor); }
	public StringProperty sorProperty() {return sor;}

	}

	


