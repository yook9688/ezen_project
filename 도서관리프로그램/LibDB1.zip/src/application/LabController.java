package application;

import java.time.LocalDate;

import application.model.Books;
import application.model.Notice;
import application.model.Review;
import application.model.Sell_list;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class LabController {
	@FXML private TableView<Books> bookTable;
	@FXML private TableColumn<Books,String> catetable;
	@FXML private TableColumn<Books,String> titletable; 
	@FXML private TableColumn<Books,String> authortable;
	@FXML private TableColumn<Books,String> companytable;
	@FXML private TableColumn<Books,String> pricetable;
	@FXML private TableColumn<Books,String> eachtable;
	
	//////////////////////////////////////////////////////////////
	//////////////////////////sell_list///////////////////////////
	//////////////////////////////////////////////////////////////
	
	@FXML private TableView<Sell_list> sellTable;
	@FXML private TableColumn<Sell_list,String> cate;
	@FXML private TableColumn<Sell_list,String> tit;
	@FXML private TableColumn<Sell_list,String> auth;
	@FXML private TableColumn<Sell_list,String> com;
	@FXML private TableColumn<Sell_list,String> pri;
	@FXML private TableColumn<Sell_list,String> id;
	@FXML private TableColumn<Sell_list,String> paid;
	@FXML private TableColumn<Sell_list,LocalDate> date;
	@FXML private TableColumn<Sell_list,String> sor;
	
//////////////////////////////////////////////////////////////
//////////////////////////sell_list///////////////////////////
//////////////////////////////////////////////////////////////
	
	@FXML private TableView<Notice> noticeTable;
	@FXML private TableColumn<Notice,String> noticeNum;
	@FXML private TableColumn<Notice,String> noticeTitle;
	@FXML private TableColumn<Notice,String> noticeContent;
	@FXML private TableColumn<Notice,LocalDate> writeDate;
	@FXML private TableColumn<Notice,String> lookUp;
	//////////////////////////////////////////////////////////
	
	@FXML private TableView<Review> reviewTable;
	@FXML private TableColumn<Review, String> num3;
	@FXML private TableColumn<Review, String> tit3;
	@FXML private TableColumn<Review, String> id3;
	@FXML private TableColumn<Review, LocalDate> date3;
	@FXML private TableColumn<Review, String> view3;
	
	private Main main;
	
	
	@FXML
	private void initialize() {
		//����ó ���̺��� �� ���� �ʱ�ȭ�Ѵ�.
		catetable.setCellValueFactory(cellData -> cellData.getValue().categoryProperty());
		titletable.setCellValueFactory(cellData -> cellData.getValue().bookTitleProperty());
		authortable.setCellValueFactory(cellData -> cellData.getValue().authurProperty());
		companytable.setCellValueFactory(cellData -> cellData.getValue().companyProperty());
		pricetable.setCellValueFactory(cellData -> cellData.getValue().priceProperty());
		eachtable.setCellValueFactory(cellData -> cellData.getValue().eachProperty());
		
		////////////////////////////////////////////////////////////////////////////////////
		
		//�Ǹ���Ȳ ���̺� �ʱ�ȭ
		cate.setCellValueFactory(cellData -> cellData.getValue().cateProperty());
		tit.setCellValueFactory(cellData -> cellData.getValue().titProperty());
		auth.setCellValueFactory(cellData -> cellData.getValue().authProperty());
		com.setCellValueFactory(cellData -> cellData.getValue().comProperty());
		pri.setCellValueFactory(cellData -> cellData.getValue().priProperty());
		id.setCellValueFactory(cellData -> cellData.getValue().idProperty());
		paid.setCellValueFactory(cellData -> cellData.getValue().paidProperty());
		date.setCellValueFactory(cellData -> cellData.getValue().dateProperty());
		sor.setCellValueFactory(cellData -> cellData.getValue().sorProperty());
		
		////////////////////////////////////////////////////////////////////////////////////
				
		//�������� ���̺� �ʱ�ȭ
		noticeNum.setCellValueFactory(cellData -> cellData.getValue().noticeNumProperty());
		noticeTitle.setCellValueFactory(cellData -> cellData.getValue().noticeTitleProperty());
		noticeContent.setCellValueFactory(cellData -> cellData.getValue().NoticeContentProperty());
		writeDate.setCellValueFactory(cellData -> cellData.getValue().writeDateProperty());
		lookUp.setCellValueFactory(cellData -> cellData.getValue().lookUpProperty());
		
		///////////////////////////////////////////////////////////////////////////////////////
				
		//���� ���̺� �ʱ�ȭ
		num3.setCellValueFactory(cellData -> cellData.getValue().num3Property());
		tit3.setCellValueFactory(cellData -> cellData.getValue().tit3Property());
		id3.setCellValueFactory(cellData -> cellData.getValue().id3Property());
		date3.setCellValueFactory(cellData -> cellData.getValue().date3Property());
		view3.setCellValueFactory(cellData -> cellData.getValue().view3Property());
		
	}
	
	public void setMainApp(Main main) {
		this.main = main;
		
		//���̺��� observable ����Ʈ �����͸� �߰��Ѵ�.
		bookTable.setItems(main.getBooksData());
		
	}
	
	public void setMainApp1(Main main) {
		this.main = main;
		
		//���̺��� observable ����Ʈ �����͸� �߰��Ѵ�.
		sellTable.setItems(main.getSellData());
		
	}
	
	public void setMainApp2(Main main) {
		this.main = main;
		
		//���̺��� observable ����Ʈ �����͸� �߰��Ѵ�.
		noticeTable.setItems(main.getNoticeData());
		
	}
	
	public void setMainApp3(Main main) {
		this.main = main;
		
		//���̺��� observable ����Ʈ �����͸� �߰��Ѵ�.
		reviewTable.setItems(main.getReviewData());		
	}
	
	
	@FXML
	public void addBook(ActionEvent event) throws Exception{
	    
		Books tempBooks = new Books();
	    boolean okClicked = main.showAddBook(tempBooks);
	    if (okClicked) {
	        main.getBooksData().add(tempBooks);
	    }

	}
	
	@FXML
	private void updateBook() {
		Books selectedBooks = bookTable.getSelectionModel().getSelectedItem();
	    if (selectedBooks != null) {
	        boolean okClicked = main.showAddBook(selectedBooks);
////	        if (okClicked) {
////	            showBooksDetails(selectedBooks);
////	        }

	    } else {
	        // �ƹ��͵� �������� �ʾҴ�.
	        Alert alert = new Alert(AlertType.WARNING);
	        alert.initOwner(main.getPrimaryStage());
	        alert.setTitle("���õ��� ����.");
	        alert.setHeaderText("����Ʈ ����");
	        alert.setContentText("�ش� ����Ʈ�� ������ �ּ���.");

	        alert.showAndWait();
	    }
		
		
	}
	
	@FXML
	private void deleteBook() {
		
		int selectedIndex = bookTable.getSelectionModel().getSelectedIndex();
		
		if(selectedIndex >= 0) {
			bookTable.getItems().remove(selectedIndex);
		}else {
			//�ƹ��͵� �������� �ʾҴ�.
			Alert alert = new Alert(AlertType.WARNING);
			alert.initOwner(main.getPrimaryStage());
			alert.setTitle("���õ��� ����.");
			alert.setHeaderText("����Ʈ ����");
			alert.setContentText("�ش� ����Ʈ�� ������ �ּ���.");
			alert.showAndWait();
		}
		
		
	}
	
	@FXML
	private void searchBook() {
		
	}
	
	@FXML
	private void searchBtn() {
		
	}
	
	
	/////////////// �Ǹ���Ȳ  ///////////////////////
	@FXML
	private void searchBook2() {
		
	}
	
	@FXML
	private void searchBookBtn2() {
		
	}
	
	@FXML
	private void searchMember() {
		
	}

	@FXML
	private void searchMemberBtn() {
		
	}
	
	@FXML
	private void showAll() {
		
	}

	
	
	////////////// ����  ////////////////////////////
	@FXML
	private void reviewAll() {
		
	}
	
	
	////////////// ��������  //////////////////////////
	
	@FXML
	private void updateNotice() {
		Notice selectedNotice = noticeTable.getSelectionModel().getSelectedItem();
	    if (selectedNotice != null) {
	        boolean okClicked = main.showAddNotice(selectedNotice);
////	        if (okClicked) {
////	            showBooksDetails(selectedBooks);
////	        }

	    } else {
	        // �ƹ��͵� �������� �ʾҴ�.
	        Alert alert = new Alert(AlertType.WARNING);
	        alert.initOwner(main.getPrimaryStage());
	        alert.setTitle("���õ��� ����.");
	        alert.setHeaderText("����Ʈ ����");
	        alert.setContentText("�ش� ����Ʈ�� ������ �ּ���.");

	        alert.showAndWait();
	    }
		
		
	}
	
	@FXML
	public void addNotice(ActionEvent event) throws Exception{
	    
		Notice tempNotice = new Notice();
	    boolean okClicked = main.showAddNotice(tempNotice);
	    if (okClicked) {
	        main.getNoticeData().add(tempNotice);
	    }

	}
	
	@FXML
	private void deleteNotice() {
		
		int selectedIndex = noticeTable.getSelectionModel().getSelectedIndex();
		
		if(selectedIndex >= 0) {
			noticeTable.getItems().remove(selectedIndex);
		}else {
			//�ƹ��͵� �������� �ʾҴ�.
			Alert alert = new Alert(AlertType.WARNING);
			alert.initOwner(main.getPrimaryStage());
			alert.setTitle("���õ��� ����.");
			alert.setHeaderText("����Ʈ ����");
			alert.setContentText("�ش� ����Ʈ�� ������ �ּ���.");
			alert.showAndWait();
		}
		
		
	}
	
	
	
	

	/*private void showBooksDetails(Books books) {
		if(books != null) {
			//person ��ü�� label�� ������ ä���
//			catetable.setText(books.getCategory());
//			titletable.setText(books.getbookTitle());
//			authortable.setText(books.getAuthur());
//			companytable.setText(books.getCompany());
//			pricetable.setText(books.getPrice());
//			eachtable.setText(books.getEach());
//			
			// TODO: ������ String���� ��ȯ�ؾ� �Ѵ�!
	        // birthdayLabel.setText(...);
		}else {
			// person�� null�̸� ��� �ؽ�Ʈ�� �����.
//			catetable.setText("");
//			titletable.setText("");
//			authortable.setText("");
//			companytable.setText("");
//			pricetable.setText("");
//			eachtable.setText("");
		}
	
	}*/
}
	
//	@FXML
//	public void Buybtn() {
//		stage = (Stage)buybtn.getScene().getWindow();
//		PickupQuestionController pq = new PickupQuestionController();
//		try {
//			Parent root = FXMLLoader.load(getClass().getResource("PickupQuestion.fxml"));
//			
//		} catch(IOException e) {
//			e.printStackTrace();
//		}
//	}
	

